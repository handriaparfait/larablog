</div>

<hr>
      <footer class="page-footer">
            <div class="footer-copyright">
                  <div class="container">
                        © Copyright NNNC - All Rights Reserved
                        <a class="grey-text text-lighten-4 right" href="<?php echo e(route('indexPage')); ?>">Acceuil</a>
                  </div>
            </div>
      </footer>