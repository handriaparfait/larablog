<?php $titleTag = htmlspecialchars($post->title); ?>
<?php $__env->startSection('title', "| $titleTag"); ?>

<?php $__env->startSection('stylesheets'); ?>

<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>

<script>
    var editor_config = {
        path_absolute : "/",
        selector: "textarea",
        branding: false,
        plugins: [
            "advlist autolink lists link image charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen",
            "insertdatetime media nonbreaking save table contextmenu directionality",
            "emoticons template paste textcolor colorpicker textpattern"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media",
        relative_urls: false,
        file_browser_callback : function(field_name, url, type, win) {
            var x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
            var y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

            var cmsURL = editor_config.path_absolute + 'laravel-filemanager?field_name=' + field_name;
            if (type == 'image') {
                cmsURL = cmsURL + "&type=Images";
            } else {
                cmsURL = cmsURL + "&type=Files";
            }

            tinyMCE.activeEditor.windowManager.open({
                file : cmsURL,
                title : 'Filemanager',
                width : x * 0.8,
                height : y * 0.8,
                resizable : "yes",
                close_previous : "no"
            });
        }
    };

    tinymce.init(editor_config);
</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="row" style="margin-top: 8%">
		<div class="col-md-8 col-md-offset-2">
			<?php if(!empty($post->image)): ?>
				<img src="<?php echo e(asset('/images/' . $post->image)); ?>" width="800" height="400" />
			<?php endif; ?>
			<h1><?php echo e($post->title); ?></h1>
			<p><?php echo $post->body; ?></p>
			<hr>
			<p>Posted In: <?php echo e($post->category->name); ?></p>
		</div>
	</div>

	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h3 class="comments-title"><span class="glyphicon glyphicon-comment"></span>  <?php echo e($post->comments()->count()); ?> Comments</h3>
			<?php foreach($post->comments as $comment): ?>
				<ul class="collection">
					<li class="collection-item avatar">
						<img src="<?php echo e("https://www.gravatar.com/avatar/" . md5(strtolower(trim($comment->email))) . "?s=50&d=monsterid"); ?>" class="circle">
						<b class="title"><?php echo e($comment->name); ?></b>
						<p><?php echo $comment->comment; ?> <br>
							<small><?php echo e(date('F dS, Y - g:iA' ,strtotime($comment->created_at))); ?></small>
						</p>
					</li>
				</ul>
			<?php endforeach; ?>
		</div>
	</div>

	<div class="row card-panel">
		<h5>Add Comments :</h5>
		<div id="comment-form" class="col-md-8 col-md-offset-2" style="margin-top: 50px;">
			<?php echo e(Form::open(['route' => ['comments.store', $post->id], 'method' => 'POST'])); ?>


				<div class="row">
					<div class="col s12 m6">
						<?php echo e(Form::label('name', "Name:")); ?>

						<?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

					</div>

					<div class="col s12 m6">
						<?php echo e(Form::label('email', 'Email:')); ?>

						<?php echo e(Form::text('email', null, ['class' => 'form-control'])); ?>

					</div>

					<div class="col-md-12">
						<?php echo e(Form::label('comment', "Comment:")); ?>

						<?php echo e(Form::textarea('comment', null, ['class' => 'form-control', 'rows' => '5'])); ?>


						<?php echo e(Form::submit('Add Comment', ['class' => 'btn btn-success btn-block', 'style' => 'margin-top:15px;'])); ?>

					</div>
				</div>

			<?php echo e(Form::close()); ?>

		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>