<?php $__env->startSection('title', '| Homepage'); ?>

<?php $__env->startSection('content'); ?>

    <div class="section no-pad-bot" id="index-banner">
        <div class="container">
            <br><br>
            <h1 class="header center orange-text">Welcome to TrockZombi</h1>
            <div class="row center">
                <h5 class="header col s12 light">Plateforme d'echange ..... bla blatage</h5>
            </div>
            <div class="row center">
                <a href="<?php echo e(route('posts.create')); ?>" id="download-button" class="btn-large waves-effect waves-light orange">Commencer à Posté</a>
            </div>
            <br><br>

        </div>
    </div>


    <div class="container" style="width: 100%">
        <div class="section">

            <!--   Icon Section   -->
            <div class="row">
                <div class="col s12 m8">
                    <ul class="collection">
                        <?php foreach($posts as $post): ?>
                        <li class="collection-item avatar">
                            <i class="material-icons circle">folder</i>
                            <b class="title"><?php echo e($post->title); ?></b> <small class="blue-text text-darken-2">- Néo-zone: <?php echo e($post->category->name); ?></small>
                            <p><i><?php echo e(substr(strip_tags($post->body), 0, 300)); ?><?php echo e(strlen(strip_tags($post->body)) > 300 ? "..." : ""); ?></i></p>
                            <a href="<?php echo e(route('blog.single', $post->slug)); ?>" class="secondary-content"><i class="material-icons">send</i></a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div class="col s12 m4">
                    <ul class="collection with-header">
                        <li class="collection-header"><h4>Catégories</h4></li>
                        <li>
                            <div class="collection">
                                <?php foreach( $categories as $category): ?>
                                    <a href="#!" class="collection-item"><?php echo e($category->name); ?></a>
                                <?php endforeach; ?>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
        <br><br>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>