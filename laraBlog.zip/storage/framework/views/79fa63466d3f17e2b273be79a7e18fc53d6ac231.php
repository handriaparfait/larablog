<ul id="dropdown1" class="dropdown-content">
  <li><a href="<?php echo e(route('posts.index')); ?>">Posts</a></li>
  <li class="divider"></li>
  <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
</ul>

<nav class="light-red darken-2">
  <div class="nav-wraper container">
    <a href="<?php echo e(URL::to('trocksystem')); ?>" class="brand-logo">ZOMBIE</a>
    <ul id="nav-mobile" class="right hide-on-med-and-down">
      <?php if(Auth::check()): ?>
      <li><a href="" class="dropdown-trigger" data-target="dropdown1">Hello <?php echo e(Auth::user()->name); ?> > </a></li>
        <li><a href="<?php echo e(route('tags.index')); ?>">Tags</a></li>
        <li><a href="<?php echo e(route('categories.index')); ?>">Noe-Zone</a></li>
    </ul>
    <?php else: ?>
      <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
      <li><a href="/auth/register">Register</a></li>
    <?php endif; ?>
  </div>

</nav>

